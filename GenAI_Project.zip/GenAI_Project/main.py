import streamlit as st
import speech_recognition as sr
from gtts import gTTS
import os
from openai import OpenAI
import threading

# Initialize OpenAI client
client = OpenAI(api_key='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')

# Initialize Speech Recognizer
recognizer = sr.Recognizer()

# Function to listen for voice commands
def listen():
    with sr.Microphone() as source:
        st.write("Listening for 'Hey Robot'...")
        while True:
            try:
                audio = recognizer.listen(source)
                text = recognizer.recognize_google(audio)
                st.write(f"Recognized: {text}")
                # Check for wake word
                if "hey robot" in text:
                    st.write("Wake word detected! Listening for your command...")
                    audio = recognizer.listen(source)
                    text = recognizer.recognize_google(audio).lower()                        
                    return text
            except sr.UnknownValueError:
                st.write("I did not understand that")
            except sr.RequestError:
                st.write("Request Failed")

# Function to get response from OpenAI ChatGPT
def get_chatgpt_response(text):    
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "system", "content": "I want you to act as a physics tutor. I will provide some physics equations or concepts, and it will be your job to solve it. "}, 
                  {"role": "user", "content": text}]
    )   
    return response.choices[0].message.content

# Function to speak response
def speak(text):
    tts = gTTS(text=text, lang='en')
    tts.save("response.mp3")
    os.system("start response.mp3")

# Function to run voice assistant
def run_voice_assistant():
    while True:
        command = listen()
        if command:
            st.write("You said:", command)
            if 'quit' in command.lower() or 'exit' in command.lower():
                st.write("Exiting voice assistant...")
                break
            response = get_chatgpt_response(command)
            st.write("ChatGPT:", response)
            speak(response)

def main():
    st.title("PhysicsWhiz Assistant")
    if st.button("Ask Questions.."):
        run_voice_assistant()

if __name__ == "__main__":
    main()
